function im_wiener = my_wiener(img, H, K)

