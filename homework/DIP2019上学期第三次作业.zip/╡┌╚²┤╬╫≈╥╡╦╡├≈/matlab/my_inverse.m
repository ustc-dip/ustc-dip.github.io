function [im_inverse, im_inverse_b] = my_inverse(img, H, D0)

[M,N] = size(img);

