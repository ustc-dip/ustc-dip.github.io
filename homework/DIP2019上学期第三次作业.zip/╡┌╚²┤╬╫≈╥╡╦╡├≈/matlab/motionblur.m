function [H, im_blured] = motionblur(img, sigma)

[M,N] = size(img);

