% EEIS Department, USTC
function [img_2] = myHisteq(img_1, n)  
% n表示输出图像的灰度级数量

size_1 = size(img_1);
h = size_1(1);
w = size_1(2);
img_2 = zeros(h, w);


end
